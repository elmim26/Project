# Project

# pigments.dat: COLOR INDEX, PIGMENT NAME, J, C,aC,bC,HueAngle,Hue Purity,aHP,bHP
# paints.dat: C.I.NAME, MARKETING NAME, Manufacturer, Code,
# Tr, St, VR, Gr, Bl, Df, HA, HS, Lf


#SUBMISSION:
finished question 4, waiting on partner to finish question 5

